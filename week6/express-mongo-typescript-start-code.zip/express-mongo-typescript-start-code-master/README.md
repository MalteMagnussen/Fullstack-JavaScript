## first thing you should do is to create af file `.env` in the root of the project with this content

DB_URI=REPLACE_WITH_YOUR_DATABASE_CONNECTION_STRING

DB_TEST_URI=REPLACE_WITH_YOUR_DATABASE_CONNECTION_STRING

DB_DEV=dev_game

DB_TEST=test_game

PORT=5555
