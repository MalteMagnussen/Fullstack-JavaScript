
export const SERVER_URL = "https://53fea3f7.ngrok.io";
