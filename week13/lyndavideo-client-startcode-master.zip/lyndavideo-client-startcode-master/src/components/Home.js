import React from "react"

export default function Home() {
  return (
    <div>
      <h2>GraphQL/Apollo demo</h2>
      <p>
        This is meant as a simple client demo, using the GraphQL API provided by the Lynda Friends Video
      </p>
    </div>
  );
}