export default interface IGameUser { 
    name: string, 
    userName: string, 
    password: string, 
    role: string 
}