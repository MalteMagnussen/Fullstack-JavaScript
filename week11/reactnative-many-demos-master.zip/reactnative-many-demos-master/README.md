# Start Code for a React Native Exercise given at cphbusiness.dk

## How to use
- Clone or fork the project
- npm install
- nmp start
- follow the instructions on the info-page
