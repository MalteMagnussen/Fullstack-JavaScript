export default interface IPoint {
    type: string
    coordinates : Array<number>
}